``` ini

BenchmarkDotNet=v0.12.1, OS=ubuntu 20.04
Intel Xeon Processor (Cascadelake), 2 CPU, 64 logical and 32 physical cores
.NET Core SDK=3.1.404
  [Host]     : .NET Core 3.1.10 (CoreCLR 4.700.20.51601, CoreFX 4.700.20.51901), X64 RyuJIT
  DefaultJob : .NET Core 3.1.10 (CoreCLR 4.700.20.51601, CoreFX 4.700.20.51901), X64 RyuJIT


```
|     Method | InputSize |           InputOrder |         Mean |      Error |     StdDev | Ratio |
|----------- |---------- |--------------------- |-------------:|-----------:|-----------:|------:|
| **Sequential** |   **1000000** |           **decreasing** |    **102.12 ms** |   **0.499 ms** |   **0.467 ms** |  **1.00** |
|   Parallel |   1000000 |           decreasing |     71.53 ms |   1.207 ms |   1.008 ms |  0.70 |
|            |           |                      |              |            |            |       |
| **Sequential** |   **1000000** |           **increasing** |     **87.01 ms** |   **0.347 ms** |   **0.308 ms** |  **1.00** |
|   Parallel |   1000000 |           increasing |     66.95 ms |   0.513 ms |   0.455 ms |  0.77 |
|            |           |                      |              |            |            |       |
| **Sequential** |   **1000000** |            **unordered** |    **142.46 ms** |   **0.766 ms** |   **0.716 ms** |  **1.00** |
|   Parallel |   1000000 |            unordered |    123.30 ms |   0.901 ms |   0.704 ms |  0.87 |
|            |           |                      |              |            |            |       |
| **Sequential** |   **1000000** | **unord(...)iform [21]** |    **238.87 ms** |   **1.107 ms** |   **1.035 ms** |  **1.00** |
|   Parallel |   1000000 | unord(...)iform [21] |    169.19 ms |   1.366 ms |   1.211 ms |  0.71 |
|            |           |                      |              |            |            |       |
| **Sequential** |  **10000000** |           **decreasing** |  **1,035.11 ms** |   **3.472 ms** |   **2.899 ms** |  **1.00** |
|   Parallel |  10000000 |           decreasing |    612.40 ms |   8.250 ms |   7.717 ms |  0.59 |
|            |           |                      |              |            |            |       |
| **Sequential** |  **10000000** |           **increasing** |    **818.35 ms** |  **12.159 ms** |  **10.779 ms** |  **1.00** |
|   Parallel |  10000000 |           increasing |    577.16 ms |   2.183 ms |   1.823 ms |  0.70 |
|            |           |                      |              |            |            |       |
| **Sequential** |  **10000000** |            **unordered** |  **1,530.67 ms** |  **12.283 ms** |  **11.489 ms** |  **1.00** |
|   Parallel |  10000000 |            unordered |  1,189.63 ms |   2.182 ms |   1.703 ms |  0.78 |
|            |           |                      |              |            |            |       |
| **Sequential** |  **10000000** | **unord(...)iform [21]** |  **2,291.58 ms** |  **13.470 ms** |  **11.248 ms** |  **1.00** |
|   Parallel |  10000000 | unord(...)iform [21] |  1,625.82 ms |   7.514 ms |   6.661 ms |  0.71 |
|            |           |                      |              |            |            |       |
| **Sequential** | **100000000** |           **decreasing** | **10,064.89 ms** | **134.200 ms** | **118.965 ms** |  **1.00** |
|   Parallel | 100000000 |           decreasing |  6,075.10 ms |  92.674 ms |  82.153 ms |  0.60 |
|            |           |                      |              |            |            |       |
| **Sequential** | **100000000** |           **increasing** |  **8,778.59 ms** |  **36.716 ms** |  **32.548 ms** |  **1.00** |
|   Parallel | 100000000 |           increasing |  5,782.50 ms |  39.680 ms |  33.135 ms |  0.66 |
|            |           |                      |              |            |            |       |
| **Sequential** | **100000000** |            **unordered** | **15,515.33 ms** |  **40.556 ms** |  **31.663 ms** |  **1.00** |
|   Parallel | 100000000 |            unordered | 12,198.86 ms | 153.948 ms | 136.471 ms |  0.79 |
|            |           |                      |              |            |            |       |
| **Sequential** | **100000000** | **unord(...)iform [21]** | **24,611.24 ms** | **155.462 ms** | **137.813 ms** |  **1.00** |
|   Parallel | 100000000 | unord(...)iform [21] | 16,963.95 ms | 213.245 ms | 199.470 ms |  0.69 |
