﻿using System;
using System.Threading;
using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;

namespace parallel_sort
{
    internal static class SampleSort
    {
        public static int[] ParallelSort(int[] input)
        {
            var inputSize = input.Length;
            var processors = Environment.ProcessorCount;
            var subarraySize = inputSize / processors;

            var threadsSamples = new int[processors][];
            for (var i = 0; i < processors; i++)
            {
                threadsSamples[i] = new int[processors - 1];
            }

            // local sort & sample selection
            var threads = new Thread[processors];
            for (var idx = 0; idx < threads.Length; idx++)
            {
                var threadIndex = idx;
                threads[idx] = new Thread(o =>
                {
                    // local sort
                    Array.Sort(input, subarraySize * threadIndex, subarraySize);

                    // sample selection
                    var step = (double) (subarraySize - 1) / processors;
                    for (var i = 0; i < processors - 1; i++)
                    {
                        threadsSamples[threadIndex][i] =
                            input[subarraySize * threadIndex + (int) Math.Round(step * (i + 1))];
                    }
                });
                threads[idx].Start();
            }

            foreach (var t in threads)
            {
                t.Join();
            }

            // merge samples
            var mergedSamples = new int[processors * (processors - 1)];
            for (var threadIndex = 0; threadIndex < processors; threadIndex++)
            {
                for (var i = 0; i < processors - 1; i++)
                {
                    mergedSamples[threadIndex * (processors - 1) + i] = threadsSamples[threadIndex][i];
                }
            }

            // global splitter selection
            var allSamples = new int[processors - 1];
            var step = (double) (processors - 1);
            for (var i = 0; i < processors - 1; i++)
            {
                allSamples[i] = mergedSamples[(int) Math.Round(step * (i + 1))];
            }

            Array.Sort(allSamples);

            // assign elements to buckets
            var elementBucket = new int[inputSize];
            var bucketSizes = new int[processors];
            for (var i = 0; i < inputSize; i++)
            {
                var threadIndex = 0;
                while (threadIndex < processors - 1 && input[i] >= allSamples[threadIndex])
                {
                    threadIndex++;
                }

                elementBucket[i] = threadIndex;
                bucketSizes[threadIndex]++;
            }

            // create and fill buckets with corresponding elements 
            var buckets = new int[processors][];
            for (var i = 0; i < processors; i++)
            {
                buckets[i] = new int[bucketSizes[i]];
            }

            var bucketIndexes = new int[processors];
            for (var i = 0; i < inputSize; i++)
            {
                var bucket = elementBucket[i];
                buckets[bucket][bucketIndexes[bucket]++] = input[i];
            }

            // sort buckets in threads
            for (var idx = 0; idx < threads.Length; idx++)
            {
                var threadIndex = idx;
                threads[idx] = new Thread(o => { Array.Sort(buckets[threadIndex]); });
                threads[idx].Start();
            }

            foreach (var t in threads)
            {
                t.Join();
            }

            // prepare the output array
            var output = new int[inputSize];
            var bucketIndex = 0;
            for (var i = 0; i < inputSize;)
            {
                for (var j = 0; j < buckets[bucketIndex].Length; j++)
                {
                    output[i] = buckets[bucketIndex][j];
                    i++;
                }

                bucketIndex++;
            }

            return output;
        }

        public static int[] SequentialSort(int[] input)
        {
            var inputSize = input.Length;
            var processors = Environment.ProcessorCount;
            var subarraySize = inputSize / processors;

            var threadsSamples = new int[processors][];
            for (var i = 0; i < processors; i++)
            {
                threadsSamples[i] = new int[processors - 1];
            }

            // local sort & sample selection
            var threads = new Thread[processors];
            for (var idx = 0; idx < threads.Length; idx++)
            {
                var threadIndex = idx;
                threads[idx] = new Thread(o =>
                {
                    // local sort
                    Array.Sort(input, subarraySize * threadIndex, subarraySize);

                    // sample selection
                    var step = (double) (subarraySize - 1) / processors;
                    for (var i = 0; i < processors - 1; i++)
                    {
                        threadsSamples[threadIndex][i] =
                            input[subarraySize * threadIndex + (int) Math.Round(step * (i + 1))];
                    }
                });
                threads[idx].Start();
                threads[idx].Join();
            }

            // merge samples
            var mergedSamples = new int[processors * (processors - 1)];
            for (var threadIndex = 0; threadIndex < processors; threadIndex++)
            {
                for (var i = 0; i < processors - 1; i++)
                {
                    mergedSamples[threadIndex * (processors - 1) + i] = threadsSamples[threadIndex][i];
                }
            }

            // global splitter selection
            var allSamples = new int[processors - 1];
            var step = (double) (processors - 1);
            for (var i = 0; i < processors - 1; i++)
            {
                allSamples[i] = mergedSamples[(int) Math.Round(step * (i + 1))];
            }

            Array.Sort(allSamples);

            // assign elements to buckets
            var elementBucket = new int[inputSize];
            var bucketSizes = new int[processors];
            for (var i = 0; i < inputSize; i++)
            {
                var threadIndex = 0;
                while (threadIndex < processors - 1 && input[i] >= allSamples[threadIndex])
                {
                    threadIndex++;
                }

                elementBucket[i] = threadIndex;
                bucketSizes[threadIndex]++;
            }

            // create and fill buckets with corresponding elements 
            var buckets = new int[processors][];
            for (var i = 0; i < processors; i++)
            {
                buckets[i] = new int[bucketSizes[i]];
            }

            var bucketIndexes = new int[processors];
            for (var i = 0; i < inputSize; i++)
            {
                var bucket = elementBucket[i];
                buckets[bucket][bucketIndexes[bucket]++] = input[i];
            }

            // sort buckets in threads
            for (var idx = 0; idx < threads.Length; idx++)
            {
                var threadIndex = idx;
                threads[idx] = new Thread(o => { Array.Sort(buckets[threadIndex]); });
                threads[idx].Start();
                threads[idx].Join();
            }

            // prepare the output array
            var output = new int[inputSize];
            var bucketIndex = 0;
            for (var i = 0; i < inputSize;)
            {
                for (var j = 0; j < buckets[bucketIndex].Length; j++)
                {
                    output[i] = buckets[bucketIndex][j];
                    i++;
                }

                bucketIndex++;
            }

            return output;
        }
    }

    [RPlotExporter]
    [HtmlExporter]
    [PlainExporter]
    [CsvExporter]
    [CsvMeasurementsExporter]
    public class Benchmarks
    {
        [Params(1000000, 10000000, 100000000)] public int InputSize { get; set; }


        [Params("unordered non-uniform", "unordered", "increasing", "decreasing")]
        public string InputOrder { get; set; }

        public int[] Input;

        public Random RandomGenerator { get; set; }

        [GlobalSetup]
        public void Init()
        {
            Input = new int[InputSize];
            RandomGenerator = new Random();
        }

        public void Fill()
        {
            switch (InputOrder)
            {
                case "unordered non-uniform":
                    for (var i = 0; i < InputSize; i++)
                    {
                        Input[i] = RandomGenerator.Next() * RandomGenerator.Next();
                    }

                    break;
                case "unordered uniform":
                    for (var i = 0; i < InputSize; i++)
                    {
                        Input[i] = RandomGenerator.Next();
                    }

                    break;
                case "increasing":
                    for (var i = 0; i < InputSize; i++)
                    {
                        Input[i] = i;
                    }

                    break;
                case "decreasing":
                    for (var i = 0; i < InputSize; i++)
                    {
                        Input[i] = InputSize - i;
                    }

                    break;
            }
        }

        [Benchmark(Baseline = true)]
        public void Sequential()
        {
            Fill();
            SampleSort.SequentialSort(Input);
        }

        [Benchmark]
        public void Parallel()
        {
            Fill();
            SampleSort.ParallelSort(Input);
        }
    }

    internal static class Program
    {
        private static void Main()
        {
            var b = BenchmarkRunner.Run<Benchmarks>();
        }
    }
}